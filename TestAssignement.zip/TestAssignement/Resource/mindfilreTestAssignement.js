/*
Project:			TestAssignement
Author:				Nikhil Saxena
Createion Date:		23-07-2019
Purpose:			Test Assignement
*/

$(document).ready(function(){				
					$.extend( $.fn.dataTable.defaults, {
					 	 	searching: false,
							ordering:  false
					} );
										
					$('#myTable').dataTable();		
					
					$('.all-product').click(function(){
						document.forms[0].submit();						
					})
				});
				
				
getTotalRows = function() {
var isGrid = ColdFusion.Grid.getGridObject('gridsview');
 var isData = isGrid.getStore();
 isData.addListener("load", function() {
	 $('.supplier-logo').click(function(){			
							$('#supplierid').val($(this)[0].id)
							document.forms[0].submit();						
						})
	 if(isData.totalLength == 0) {

	   return false;
	 }
 });
}
ColdFusion.Event.registerOnLoad(getTotalRows,null,false,true);

